function b(h,i,e){var f=-1,l=h.length;i<0&&(i=-i>l?0:l+i),e=e>l?l:e,e<0&&(e+=l),l=i>e?0:e-i>>>0,i>>>=0;for(var u=Array(l);++f<l;)u[f]=h[f+i];return u}export{b};
//# sourceMappingURL=_baseSlice-F8doVSIJ.js.map
