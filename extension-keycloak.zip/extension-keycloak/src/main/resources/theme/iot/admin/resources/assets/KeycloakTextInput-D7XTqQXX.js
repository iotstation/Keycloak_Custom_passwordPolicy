import{jsx as n}from"react/jsx-runtime";import{forwardRef as e}from"react";import{aX as p}from"./index-BJxbFIr2.js";const m=e(({onChange:o,...r},t)=>n(p,{...r,ref:t,onChange:(f,a)=>o?.(a)}));m.displayName="TextInput";export{m as K};
//# sourceMappingURL=KeycloakTextInput-D7XTqQXX.js.map
