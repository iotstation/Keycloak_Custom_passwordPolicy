import{jsx as t}from"react/jsx-runtime";import{forwardRef as n}from"react";import{cW as m}from"./index-BJxbFIr2.js";const s=n(({onChange:r,...o},a)=>t(m,{...o,ref:a,onChange:(p,e)=>r?.(e)}));s.displayName="TextArea";export{s as K};
//# sourceMappingURL=KeycloakTextArea-B9oWPeFZ.js.map
