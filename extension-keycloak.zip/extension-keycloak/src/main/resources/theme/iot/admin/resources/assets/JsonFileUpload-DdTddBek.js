import{jsx as e}from"react/jsx-runtime";import{F as s}from"./FileUploadForm-DZa7uxgQ.js";import{L as i}from"./CodeEditor-ByKGz2uS.js";const p=({onChange:o,...n})=>{const r=a=>{try{o(JSON.parse(a))}catch{o({}),console.warn("Invalid json, ignoring value using {}")}};return e(s,{...n,language:i.json,extension:".json",onChange:r})};export{p as J};
//# sourceMappingURL=JsonFileUpload-DdTddBek.js.map
