import{dR as s}from"./index-BJxbFIr2.js";function o(a,r){return s(a,r)}export{o as i};
//# sourceMappingURL=isEqual-DWOqTb4L.js.map
