import{_ as e,k as o}from"./index-BJxbFIr2.js";import*as m from"react";import{s as i}from"./DataListItemRow-DhylnS50.js";const l=s=>{var{children:a,className:t=""}=s,r=e(s,["children","className"]);return m.createElement("div",Object.assign({className:o(i.dataListItemControl,t)},r),a)};l.displayName="DataListControl";export{l as D};
//# sourceMappingURL=DataListControl-BjyGt6wZ.js.map
