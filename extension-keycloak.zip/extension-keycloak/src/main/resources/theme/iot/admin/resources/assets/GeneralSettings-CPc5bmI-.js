import{jsxs as s,Fragment as i,jsx as r}from"react/jsx-runtime";import{R as o,D as a}from"./DisplayOrder-BWu02fqA.js";import{C as m}from"./ClientIdSecret-kdRVD9O9.js";const c=({create:e=!0,id:t})=>s(i,{children:[r(o,{id:t}),r(m,{create:e}),r(a,{})]});export{c as G};
//# sourceMappingURL=GeneralSettings-CPc5bmI-.js.map
