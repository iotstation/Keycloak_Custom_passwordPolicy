var E;(function(I){I.AFFIRMATIVE="AFFIRMATIVE",I.UNANIMOUS="UNANIMOUS",I.CONSENSUS="CONSENSUS"})(E||(E={}));var N;(function(I){I.Permit="PERMIT",I.Deny="DENY"})(N||(N={}));var S;(function(I){I.POSITIVE="POSITIVE",I.NEGATIVE="NEGATIVE"})(S||(S={}));export{N as D,E as a};
//# sourceMappingURL=policyRepresentation-LeM_FTje.js.map
