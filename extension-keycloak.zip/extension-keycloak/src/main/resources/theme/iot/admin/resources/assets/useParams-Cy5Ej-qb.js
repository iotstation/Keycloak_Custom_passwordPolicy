import{d as s}from"./index-BJxbFIr2.js";const r=()=>s();export{r as u};
//# sourceMappingURL=useParams-Cy5Ej-qb.js.map
