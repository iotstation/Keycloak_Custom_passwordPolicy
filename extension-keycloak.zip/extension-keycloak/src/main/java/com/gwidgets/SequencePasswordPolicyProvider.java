package com.gwidgets;

import org.keycloak.models.RealmModel;
import org.keycloak.models.UserModel;
import org.keycloak.policy.PasswordPolicyProvider;
import org.keycloak.policy.PolicyError;

public class SequencePasswordPolicyProvider implements PasswordPolicyProvider {
    @Override
    public PolicyError validate(RealmModel realm, UserModel user, String password) {
        return validate(null, password);
    }

    @Override
    public PolicyError validate(String user, String password) {
        if (containsSequence(password)) {
            return new PolicyError("Password must not contain a sequence of three or more consecutive numbers or letters.");
        } else {
            return null;
        }
    }

    @Override
    public Object parseConfig(String value) {
        return null;
    }

    @Override
    public void close() {
        // No resources to clean up
    }

    private boolean containsSequence(String password) {
        int length = password.length();
        for (int i = 0; i < length - 2; i++) {
            char first = password.charAt(i);
            char second = password.charAt(i + 1);
            char third = password.charAt(i + 2);

            // Check for numeric sequence
            if (Character.isDigit(first) && Character.isDigit(second) && Character.isDigit(third)) {
                int firstNumber = Character.getNumericValue(first);
                int secondNumber = Character.getNumericValue(second);
                int thirdNumber = Character.getNumericValue(third);
                if (firstNumber + 1 == secondNumber && secondNumber + 1 == thirdNumber) {
                    return true;
                }
            }

            // Check for alphabetic sequence
            if (Character.isLetter(first) && Character.isLetter(second) && Character.isLetter(third)) {
                if (first + 1 == second && second + 1 == third) {
                    return true;
                }
            }
        }
        return false;
    }
}

